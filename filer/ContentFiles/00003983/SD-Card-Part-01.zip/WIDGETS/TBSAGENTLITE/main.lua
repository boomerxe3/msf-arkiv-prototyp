-------------------------------------------------------------------------------
-- TBS Agent 0.98 Widget
-- release date: 2024-01
-- author: JimB40
-------------------------------------------------------------------------------
local SP = '/SCRIPTS/TOOLS/TBSAGENTLITE/'
return loadScript(SP..'WIDGET/loader','Tx')(SP,'TBS Agent','Tx')
